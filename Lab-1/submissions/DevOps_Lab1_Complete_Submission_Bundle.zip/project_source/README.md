# DevOps Foundations & Continuous Integration (Lab 1)

**Student Name:** Naman Joshi  
**GitHub:** [Naman09746](https://github.com/Naman09746)  
**Email:** joshinaman2005@gmail.com  
**Course:** DevOps Foundations & Continuous Integration  
**Target Environment:** Ubuntu Linux 24.04 LTS, Git, Jenkins, Python 3.10+, Docker  

---

## 🚀 Project Overview
This repository contains a complete, production-grade DevOps Continuous Integration and Continuous Deployment (CI/CD) implementation:
1. **Application**: Production Flask microservice (`app.py`) with UI dashboard, `/health` and `/metrics` monitoring endpoints.
2. **Automated Testing**: Pytest suite (`test_app.py`) verifying status codes, JSON payload integrity, and error boundaries.
3. **Containerization**: `Dockerfile` based on `python:3.10-slim`.
4. **Automated Deployment**: `deploy.sh` script providing automated restarts, smoke testing, and zero-downtime container management.
5. **Pipeline as Code**: Declarative 6-stage `Jenkinsfile` managing checkout, build, testing (with JUnit reports), packaging (`.tar.gz`), deployment, and health verification.
6. **Academic Reports**: Automated PDF & Markdown report generation scripts powered by `reportlab`.

---

## 📁 Repository Structure
```text
Lab-1/
├── app.py                     # Flask Web Application with UI & Health/Metrics APIs
├── test_app.py                # Automated Pytest suite with JUnit report support
├── requirements.txt           # Python dependencies (Flask, pytest)
├── Dockerfile                 # Container packaging definition
├── deploy.sh                  # Application deployment script with rollback & health check
├── Jenkinsfile                # Declarative 6-Stage CI/CD Jenkins pipeline
├── build_master.py            # Master submission builder (PDFs, Markdown, ZIP)
├── build_q1.py - build_q7.py  # Individual question report builders
├── README.md                  # Project documentation
└── submissions/               # Ready-to-upload submission files (PDFs, Markdown & ZIP)
    ├── Q1_Record_All_Commands.pdf / .md
    ├── Q2_CICD_Workflow_Report.pdf / .md
    ├── Q3_Automated_Deployment_Jenkins.pdf / .md
    ├── Q4_Install_Configure_Git_Jenkins.pdf / .md
    ├── Q5_Git_Version_Control_Setup.pdf / .md
    ├── Q6_Basic_Jenkins_CICD_Pipeline.pdf / .md
    ├── Q7_Jenkinsfile_Pipeline_Stages.pdf / .md
    ├── DevOps_Lab1_Comprehensive_Submission_Report.pdf
    └── DevOps_Lab1_Complete_Submission_Bundle.zip
```

---

## ⚡ Quick Start & Verification

### 1. Run Application Locally
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 app.py
# Application accessible at http://localhost:5000
```

### 2. Run Automated Tests
```bash
pytest test_app.py -v
```

### 3. Re-generate Submission PDFs
```bash
python3 build_master.py
```

### 4. Push to Your GitHub Repository
```bash
git remote add origin https://github.com/Naman09746/DevOps.git
git branch -M main
git push -u origin main
```
